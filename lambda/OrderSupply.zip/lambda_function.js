const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const tableName = 'SupplyOrders';
    const counterTableName = 'PrimaryKeyCounter';

    try {
        // Get the next OrderID
        const counterParams = {
            TableName: counterTableName,
            Key: { TableName: tableName },
            UpdateExpression: "set LastOrderID = if_not_exists(LastOrderID, :start) + :increment",
            ExpressionAttributeValues: {
                ":start": 0, // Initialize the counter if it doesn't exist
                ":increment": 1
            },
            ReturnValues: "UPDATED_NEW"
        };

        const counterResult = await dynamoDB.update(counterParams).promise();
        const nextOrderID = `SO${String(counterResult.Attributes.LastOrderID).padStart(3, '0')}`;

        // Add the new record to the SupplyOrders table
        const { CustomerID, Delivered, EstimatedDeliveryDate, OrderDate, ItemName, OrderAmount } = event;

        const params = {
            TableName: tableName,
            Item: {
                OrderID: nextOrderID,
                CustomerID,
                Delivered: Delivered || false,
                EstimatedDeliveryDate: EstimatedDeliveryDate || null,
                OrderDate: OrderDate || new Date().toISOString().split('T')[0],
                ItemName,
                OrderAmount
            }
        };

        console.log("PutItem parameters:", JSON.stringify(params, null, 2)); // Log the request
        await dynamoDB.put(params).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Order added successfully", OrderID: nextOrderID }),
        };
    } catch (error) {
        console.error("Error adding order:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message }),
        };
    }
};
